import React, { useState } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { Card } from './components/Card';
import { Button } from './components/Button';
import { Icon } from './components/Icon';

const App: React.FC = () => {
  const [bids] = useState([
    { address: '0xcf5f...Be65', amount: 0.0006 },
    { address: '0xab12...Cd78', amount: 0.0005 },
    { address: '0xef34...Gh90', amount: 0.0004 },
  ]);

  return (
    <div className="min-h-screen text-white font-sans flex flex-col">
      <div className="relative z-10 container mx-auto px-4 py-8 flex-grow">
        <Header />

        <main className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Top Row */}
          <div className="lg:col-span-3 grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card title="SDS Data (Demo Purpose)" icon={<Icon name="sds" />}>
              <div className="border-t border-indigo-400/50 text-sm">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-3">
                  <div>
                    <p className="font-semibold">SDS Contract:</p>
                    <a href="#" className="text-indigo-400 hover:underline break-all">0x1234567890abcdef1234567890abcdef12345678</a>
                    <a href="#" className="flex items-center space-x-1 text-gray-400 hover:text-white text-xs mt-1">
                      <Icon name="explorer" />
                      <span>View on Explorer</span>
                    </a>
                  </div>
                  <div className="mt-2 sm:mt-0 px-3 py-1 bg-green-500/20 text-green-300 rounded-full text-xs font-semibold">
                    SDS Active
                  </div>
                </div>
              </div>
            </Card>
            <Card title="Deployed Contracts" icon={<Icon name="contract" />}>
              <div className="space-y-3 text-sm">
                <p className="font-semibold">Auction Contract:</p>
                <a href="#" className="text-indigo-400 hover:underline break-all">0x3A6f8B74463fe40259B42c5BF9D354F9D136E6E</a>
                <a href="#" className="flex items-center space-x-1 text-gray-400 hover:text-white text-xs">
                  <Icon name="explorer" />
                  <span>View on Explorer</span>
                </a>
                <p className="font-semibold pt-2">NFT Contract:</p>
                <a href="#" className="text-indigo-400 hover:underline break-all">0x98e7D736A94f4AB8117c17dB186d377b75a63aa</a>
                <a href="#" className="flex items-center space-x-1 text-gray-400 hover:text-white text-xs">
                  <Icon name="explorer" />
                  <span>View on Explorer</span>
                </a>
              </div>
            </Card>
            <Card title="LIVE Stream" icon={<Icon name="stream" />}>
              <div className="bg-black/20 p-4 rounded-lg space-y-2 text-sm">
                <div className="flex items-center space-x-2 text-green-400">
                  <span className="font-bold">Connected</span>
                </div>
                <p className="text-gray-400">Waiting for live bids...</p>
              </div>
              <p className="text-xs text-gray-400 mt-2">Blockchain streaming</p>
            </Card>
          </div>

          {/* Main Content Grid */}
          <Card title="SDS Integration" icon={<Icon name="sds" />}>
            <div className="space-y-4">
              <Button fullWidth>Load SDS Schemas</Button>
              <div className="flex items-center space-x-2">
                <span className="relative flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                </span>
                <span className="text-sm text-gray-300">Real-time streaming active</span>
              </div>
            </div>
          </Card>

          <Card title="Place Your Bid" icon={<Icon name="bid" />}>
            <div className="flex flex-col sm:flex-row items-center space-y-3 sm:space-y-0 sm:space-x-4">
              <input
                type="number"
                step="0.1"
                defaultValue="0.1"
                className="bg-white/5 border border-white/20 rounded-lg px-4 py-2 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 w-full sm:w-auto flex-grow"
              />
              <span className="font-bold text-gray-400">STT</span>
              <Button variant="success" className="w-full sm:w-auto">Place Bid</Button>
            </div>
            <p className="text-xs text-gray-400 mt-2">Loading minimum bid...</p>
          </Card>

          <Card title="Auction Status" icon={<Icon name="status" />} className="lg:row-span-2 flex flex-col">
             <div className="flex-grow flex flex-col justify-center items-center space-y-4">
              <Button fullWidth>
                <div className="flex items-center justify-center space-x-2">
                  <Icon name="refresh" />
                  <span>Refresh Status</span>
                </div>
              </Button>
              <p className="text-sm text-gray-400 text-center">Loading auction status...</p>
            </div>
          </Card>

          <Card title="NFT Information" icon={<Icon name="nft" />}>
            <div className="space-y-2 text-sm">
              <p><span className="font-semibold text-gray-300">NFT Name:</span> Somnia Hackathon NFT #0</p>
              <p><span className="font-semibold text-gray-300">Contract:</span> 0xc595...e03C6</p>
              <p><span className="font-semibold text-gray-300">Token ID:</span> 0</p>
            </div>
          </Card>

          <Card title="Bid History" icon={<Icon name="history" />}>
            <div className="space-y-2 max-h-40 overflow-y-auto pr-2">
              {bids.map((bid, index) => (
                <div key={index} className="flex justify-between items-center bg-black/20 p-3 rounded-lg text-sm">
                  <span className="font-mono text-gray-300">{bid.address}</span>
                  <span className="font-bold text-indigo-400">{bid.amount.toFixed(4)} STT</span>
                </div>
              ))}
            </div>
          </Card>

        </main>
      </div>
      <Footer />
    </div>
  );
};

export default App;

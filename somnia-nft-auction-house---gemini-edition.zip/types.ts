export interface NFT {
  id: number;
  title: string;
  creator: string;
  creatorAvatar: string;
  imageUrl: string;
  currentBid: number;
  endDate: Date;
  likes: number;
}

export interface Seller {
  id: number;
  name: string;
  avatar: string;
  sales: number;
}

export interface Collection {
  id: number;
  name: string;
  creator: string;
  itemCount: number;
  mainImage: string;
  subImages: string[];
}
